// Tarea 2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Math.h"
#include <iostream>
using namespace std;

int main(void)
{float A,B,C,D,E,F,x,y; char resp='s';
while(resp=='s'|| resp=='S')
{    cout<<"Introducir los valores de A,B,C,D,E,F para las ecuaciones Ax+By=C y Dx+Ey=F"<<endl;
     cout<<"A=";
	 cin>>A;
	 cout<<"B=";
	 cin>>B;
	 cout<<"C=";
	 cin>>C;
	 cout<<"D=";
	 cin>>D;
	 cout<<"E=";
	 cin>>E;
	 cout<<"F=";
	 cin>>F;

	 y=(A*F-D*C)/(A*E-D*B);

	 if(A==D&&B==E&&C==F)
	 {cout<<"Hay infinitas soluciones para Y, y ";}
	 else
	 {if(A/B==D/E)
	 {cout<<"Las rectas no intersectan y por lo tanto no hay solucion";}
	 else
     {cout<<"El valor de Y es="<<y<<endl;}
	 }

	x=(B*F-E*C)/(B*D-E*A);

	if(A==D&&B==E&&C==F)
	{cout<<"hay infinitas soluciones para X ya que las rectas estan una encima de otra."<<endl;}
	else
	{
	if(A/B==D/E)
	{cout<<endl;}
	else
	{cout<<"El valor de X es="<<x<<endl;}
	}
cout<<"Tiene mas datos?(s/n)"<<endl;
cin>>resp;
}
system("Pause");
	return 0;
}

